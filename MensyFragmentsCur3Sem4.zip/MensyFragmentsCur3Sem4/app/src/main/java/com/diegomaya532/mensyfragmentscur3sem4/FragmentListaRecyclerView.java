package com.diegomaya532.mensyfragmentscur3sem4;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class FragmentListaRecyclerView extends Fragment {
    ArrayList<Mascota> mascotas;
    private RecyclerView listaMascotas;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista_recycler_view, container, false);
        listaMascotas = view.findViewById(R.id.rvMascotas);
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(llm);
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("Jack", "5", R.drawable.dog_00));
        mascotas.add(new Mascota("Ronnie", "1", R.drawable.dog_01));
        mascotas.add(new Mascota("Bella", "3", R.drawable.dog_02));
        mascotas.add(new Mascota("Husher", "2", R.drawable.dog_03));
        mascotas.add(new Mascota("Rocket", "4", R.drawable.dog_04));
        AdaptadorListaMascota adaptadorMascota = new AdaptadorListaMascota(mascotas, getActivity());
        listaMascotas.setAdapter(adaptadorMascota);
        return view;
    }
}